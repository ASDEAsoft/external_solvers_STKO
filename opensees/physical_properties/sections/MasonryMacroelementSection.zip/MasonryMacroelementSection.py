import PyMpc.Units as u
from PyMpc import *
from mpc_utils_html import *
import opensees.utils.tcl_input as tclin
import opensees.physical_properties.sections.offset_utils as ofu

def makeXObjectMetaData():
	
	#element type
	#tremuri
	at_tremuri = MpcAttributeMetaData()
	at_tremuri.type = MpcAttributeType.Boolean
	at_tremuri.name = 'tremuri'
	at_tremuri.group = 'Section'
	at_tremuri.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('tremuri')+'<br/>') + 
		html_par('tremuri equivalent definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Tremuri-equivalent-definition','Tremuri equivalent definition')+'<br/>') +
		html_end()
		)
	at_tremuri.editable = False
	
	#Standard
	at_standard = MpcAttributeMetaData()
	at_standard.type = MpcAttributeType.Boolean
	at_standard.name = 'standard'
	at_standard.group = 'Section'
	at_standard.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('standard')+'<br/>') + 
		html_par('standard definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Standard-element-definition','Standard definition')+'<br/>') +
		html_end()
		)
	at_standard.editable = False
	
	#fiber
	at_fiber = MpcAttributeMetaData()
	at_fiber.type = MpcAttributeType.Boolean
	at_fiber.name = 'fiber'
	at_fiber.group = 'Section'
	at_fiber.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('fiber')+'<br/>') + 
		html_par('fiber definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Fibre-section-macroelement-definition','Fibre section macroelement definition')+'<br/>') +
		html_end()
		)
	at_fiber.editable = False

	#pier
	at_pier = MpcAttributeMetaData()
	at_pier.type = MpcAttributeType.Boolean
	at_pier.name = 'pier'
	at_pier.group = 'Section'
	at_pier.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('pier')+'<br/>') + 
		html_par('standard pier definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Standard-element-definition','Standard pier definition')+'<br/>') +
		html_end()
		)
	at_pier.editable = False
	
	#spandrel
	at_spandrel = MpcAttributeMetaData()
	at_spandrel.type = MpcAttributeType.Boolean
	at_spandrel.name = 'spandrel'
	at_spandrel.group = 'Section'
	at_spandrel.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('spandrel')+'<br/>') + 
		html_par('standard spandrel definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Standard-element-definition','Standard spandrel definition')+'<br/>') +
		html_end()
		)
	at_spandrel.editable = False

	#gable
	at_gable = MpcAttributeMetaData()
	at_gable.type = MpcAttributeType.Boolean
	at_gable.name = 'gable'
	at_gable.group = 'Section'
	at_gable.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('gable')+'<br/>') + 
		html_par('standard gable definition') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Standard-element-definition','Standard gable definition')+'<br/>') +
		html_end()
		)
	at_gable.editable = False

	#fibre GL
	at_fiberGL = MpcAttributeMetaData()
	at_fiberGL.type = MpcAttributeType.Boolean
	at_fiberGL.name = 'fiberGL'
	at_fiberGL.group = 'Section'
	at_fiberGL.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('fiberGL')+'<br/>') + 
		html_par('Fibre section + Gambarotta-Lagomarsino shear model') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Fibre-section-macroelement-definition','Fibre section macroelement definition')+'<br/>') +
		html_end()
		)
	at_fiberGL.editable = False
	
	#fibre uncouple
	at_fiberUNC = MpcAttributeMetaData()
	at_fiberUNC.type = MpcAttributeType.Boolean
	at_fiberUNC.name = 'fiberUNC'
	at_fiberUNC.group = 'Section'
	at_fiberUNC.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('fiberUnc')+'<br/>') + 
		html_par('Fibre section + uncoupled shear model') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Fibre-section-macroelement-definition','Fibre section macroelement definition')+'<br/>') +
		html_end()
		)
	at_fiberUNC.editable = False
	
	# Element type
	at_ElementType = MpcAttributeMetaData()
	at_ElementType.type = MpcAttributeType.String
	at_ElementType.name = 'Type'
	at_ElementType.group = 'Section'
	at_ElementType.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Type')+'<br/>') + 
		html_par('Choose between Tremuri or Standard or Fiber') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Macroelement-definition','Macroelement definition')+'<br/>') +
		html_end()
		)
	at_ElementType.sourceType = MpcAttributeSourceType.List
	at_ElementType.setSourceList(['tremuri', 'standard','fiber'])
	at_ElementType.setDefault('standard')

	# Std Element type
	at_StdType = MpcAttributeMetaData()
	at_StdType.type = MpcAttributeType.String
	at_StdType.name = 'Standard Type'
	at_StdType.group = 'Section'
	at_StdType.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Type')+'<br/>') + 
		html_par('Choose between pier, spandrel or gable') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Macroelement-definition','Macroelement definition')+'<br/>') +
		html_end()
		)
	at_StdType.sourceType = MpcAttributeSourceType.List
	at_StdType.setSourceList(['pier', 'spandrel','gable'])
	at_StdType.setDefault('pier')

	# fiber type
	at_fiberType = MpcAttributeMetaData()
	at_fiberType.type = MpcAttributeType.String
	at_fiberType.name = 'Fiber Type'
	at_fiberType.group = 'Section'
	at_fiberType.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Type')+'<br/>') + 
		html_par('Choose between fiber shear models') +
		html_par(html_href('https://github.com/eesd-epfl/OpenSees/wiki/Fibre-section-macroelement-definition','Fibre section macroelement definition')+'<br/>') +
		html_end()
		)
	at_fiberType.sourceType = MpcAttributeSourceType.List
	at_fiberType.setSourceList(['fiberGL', 'fiberUNC'])
	at_fiberType.setDefault('fiberUNC')

	# fiber secI
	at_SectionI = MpcAttributeMetaData()
	at_SectionI.type = MpcAttributeType.Index
	at_SectionI.name = 'SectionI'
	at_SectionI.group = 'Fiber section'
	at_SectionI.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Section')+'<br/>') + 
		html_par('Fiber section I') +
		html_par(html_href('http://opensees.berkeley.edu/wiki/index.php/Fiber_Section','Fiber Section')+'<br/>') +
		html_end()
		)
	at_SectionI.indexSource.type = MpcAttributeIndexSourceType.PhysicalProperty
	at_SectionI.indexSource.addAllowedNamespace('sections') # we want fiber materials for fibers

	# fiber secJ
	at_SectionJ = MpcAttributeMetaData()
	at_SectionJ.type = MpcAttributeType.Index
	at_SectionJ.name = 'SectionJ'
	at_SectionJ.group = 'Fiber section'
	at_SectionJ.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Section')+'<br/>') + 
		html_par('Fiber section J') +
		html_par(html_href('http://opensees.berkeley.edu/wiki/index.php/Fiber_Section','Fiber Section')+'<br/>') +
		html_end()
		)
	at_SectionJ.indexSource.type = MpcAttributeIndexSourceType.PhysicalProperty
	at_SectionJ.indexSource.addAllowedNamespace('sections') # we want fiber section materials for fibers

	# fiber secE
	at_SectionE = MpcAttributeMetaData()
	at_SectionE.type = MpcAttributeType.Index
	at_SectionE.name = 'SectionE'
	at_SectionE.group = 'Fiber section'
	at_SectionE.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Section')+'<br/>') + 
		html_par('Fiber section E') +
		html_par(html_href('http://opensees.berkeley.edu/wiki/index.php/Fiber_Section','Fiber Section')+'<br/>') +
		html_end()
		)
	at_SectionE.indexSource.type = MpcAttributeIndexSourceType.PhysicalProperty
	at_SectionE.indexSource.addAllowedNamespace('sections') # we want uniaxial materials for fibers

	# fiber secIIP
	at_SectionIIP = MpcAttributeMetaData()
	at_SectionIIP.type = MpcAttributeType.Index
	at_SectionIIP.name = 'SectionIIP'
	at_SectionIIP.group = 'Fiber section'
	at_SectionIIP.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Section')+'<br/>') + 
		html_par('Fiber Section IIP') +
		html_par(html_href('http://opensees.berkeley.edu/wiki/index.php/Fiber_Section','Fiber Section')+'<br/>') +
		html_end()
		)
	at_SectionIIP.indexSource.type = MpcAttributeIndexSourceType.PhysicalProperty
	at_SectionIIP.indexSource.addAllowedNamespace('materials.uniaxial') # we want uniaxial materials for fibers

	# fiber secOOP
	at_SectionOOP = MpcAttributeMetaData()
	at_SectionOOP.type = MpcAttributeType.Index
	at_SectionOOP.name = 'SectionOOP'
	at_SectionOOP.group = 'Fiber section'
	at_SectionOOP.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Section')+'<br/>') + 
		html_par('Fiber Section OOP') +
		html_par(html_href('http://opensees.berkeley.edu/wiki/index.php/Fiber_Section','Fiber Section')+'<br/>') +
		html_end()
		)
	at_SectionOOP.indexSource.type = MpcAttributeIndexSourceType.PhysicalProperty
	at_SectionOOP.indexSource.addAllowedNamespace('materials.uniaxial') # we want uniaxial materials for fibers

	
	#input properties - general
	def mka(name, group, descr, atype, adim = None, dval = None):
		a = MpcAttributeMetaData()
		a.type = atype
		a.name = name
		a.group = group
		a.description = (
			html_par(html_begin()) +
			html_par(html_boldtext(name)+'<br/>') + 
			html_par(descr) +
			html_par(html_href('','Macroelement')+'<br/>') +
			html_end()
			)
		if adim is not None:
			a.dimension = adim
		if dval is not None:
			a.setDefault(dval)
		return a
	
	at_L = mka("Li", "Geometrical", "Length of the section (dimension in local direction y)", MpcAttributeType.QuantityScalar,adim=u.L)
	at_t = mka("t", "Geometrical", "Thickness of the section (dimension in local direction z)", MpcAttributeType.QuantityScalar,adim=u.L)
	at_E = mka("E", "Material properties", "Young\'s Modulus  of masonry", MpcAttributeType.QuantityScalar, adim=u.F/u.L**2)
	at_G = mka("G", "Material properties", "Shear modulus of masonry", MpcAttributeType.QuantityScalar, adim=u.F/u.L**2)
	at_fc = mka("fc", "Material properties", "Compressive strength", MpcAttributeType.QuantityScalar, adim=u.F/u.L**2)
	at_mu = mka("mu", "Material properties", "Friction coefficient defining the peak strength", MpcAttributeType.QuantityScalar)
	at_c = mka("c", "Material properties", "Cohesion (Mohr-Coulomb force criterion)", MpcAttributeType.QuantityScalar, adim=u.F/u.L**2)
	at_Gc = mka("Gc", "Material properties", "Parameter defining the pre-peak deformability in shear", MpcAttributeType.QuantityScalar)
	at_dropDrift = mka("dropDrift", "Material properties", "Drift at 20% force capacity loss", MpcAttributeType.QuantityScalar)
	at_muR = mka("muR", "Material properties", "Residual friction coefficient, defining residual capacity and hysteretic behaviour", MpcAttributeType.QuantityScalar)
	at_beta = mka("beta", "Material properties", "Parameter defining the post-peak response", MpcAttributeType.QuantityScalar)
	at_betaF = mka("betaF", "Material properties", "Parameter defining the post-peak response", MpcAttributeType.QuantityScalar)
	
	# Offsets for Equivalent Frame and rigid end zones ---------------
	
	# Offset i
	at_offseti = MpcAttributeMetaData()
	at_offseti.type = MpcAttributeType.QuantityScalar
	at_offseti.name = 'Offset_i'
	at_offseti.group = 'Geometrical'
	at_offseti.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Offset i')+'<br/>') + 
		html_par('Length of offset i') +
		html_end()
		)
	
	# Offset j
	at_offsetj = MpcAttributeMetaData()
	at_offsetj.type = MpcAttributeType.QuantityScalar
	at_offsetj.name = 'Offset_j'
	at_offsetj.group = 'Geometrical'
	at_offsetj.description = (
		html_par(html_begin()) +
		html_par(html_boldtext('Offset j')+'<br/>') + 
		html_par('Length of offset j') +
		html_end()
		)

	# --------------------------------------------------------------------
	
	xom = MpcXObjectMetaData()
	xom.name = 'MasonryMacroelementSection'
	#section types
	xom.addAttribute(at_ElementType)
	xom.addAttribute(at_StdType)
	xom.addAttribute(at_fiber)
	xom.addAttribute(at_fiberType)
	xom.addAttribute(at_fiberGL)
	xom.addAttribute(at_fiberUNC)
	xom.addAttribute(at_standard)
	xom.addAttribute(at_tremuri)
	xom.addAttribute(at_pier)
	xom.addAttribute(at_spandrel)
	xom.addAttribute(at_gable)
	#material params
	xom.addAttribute(at_SectionI)
	xom.addAttribute(at_SectionJ)
	xom.addAttribute(at_SectionE)
	xom.addAttribute(at_SectionIIP)
	xom.addAttribute(at_SectionOOP)
	xom.addAttribute(at_L)
	xom.addAttribute(at_t)
	xom.addAttribute(at_offseti)
	xom.addAttribute(at_offsetj)
	xom.addAttribute(at_E)
	xom.addAttribute(at_G)
	xom.addAttribute(at_fc)
	xom.addAttribute(at_mu)
	xom.addAttribute(at_c)
	xom.addAttribute(at_Gc)
	xom.addAttribute(at_muR)
	xom.addAttribute(at_dropDrift)
	xom.addAttribute(at_beta)
	xom.addAttribute(at_betaF)


	# Standard-dep
	xom.setVisibilityDependency(at_standard, at_StdType)
	xom.setVisibilityDependency(at_standard, at_muR)
	xom.setVisibilityDependency(at_standard, at_dropDrift)
	
	# tremuri-dep
	xom.setVisibilityDependency(at_tremuri, at_beta)
	
	# fiber dep
	xom.setVisibilityDependency(at_fiber, at_fiberType)
	xom.setVisibilityDependency(at_fiber, at_SectionIIP)
	xom.setVisibilityDependency(at_fiber, at_SectionOOP)
	xom.setVisibilityDependency(at_fiberUNC, at_SectionIIP)
	xom.setVisibilityDependency(at_fiberUNC, at_SectionOOP)
	
	xom.setVisibilityDependency(at_fiberGL, at_betaF)

	xom.setVisibilityDependency(at_fiber, at_SectionI)
	xom.setVisibilityDependency(at_fiber, at_SectionJ)
	xom.setVisibilityDependency(at_fiber, at_SectionE)
	
	# auto-exclusive dependencies
	xom.setBooleanAutoExclusiveDependency(at_ElementType, at_tremuri)
	xom.setBooleanAutoExclusiveDependency(at_ElementType, at_standard)
	xom.setBooleanAutoExclusiveDependency(at_ElementType, at_fiber)
	xom.setBooleanAutoExclusiveDependency(at_fiberType, at_fiberUNC)
	xom.setBooleanAutoExclusiveDependency(at_fiberType, at_fiberGL)
	
	# Massimo: 01/03/2020
	# To get the extrusion from the standard and tremuri sections (i.e. when we don't
	# reference an already existing section, we need a fake (hidden) MpcBeamSection attribute
	# (like the one in Elasic.py that will produce the output of the section extrusion for us)
	# Section
	at_dummy_section = MpcAttributeMetaData()
	at_dummy_section.type = MpcAttributeType.CustomAttributeObject
	at_dummy_section.name = 'dummy_section'
	at_dummy_section.group = 'dummy_section'
	at_dummy_section.customObjectPrototype = MpcBeamSection()
	#at_dummy_section.editable = False
	xom.addAttribute(at_dummy_section)
	
	# done
	return xom

def _get_xobj_attribute(xobj, at_name):
	'''
	private utility to get an attribute from an XObject, and raise
	an excpetion if the attribute does not exist
	'''
	attribute = xobj.getAttribute(at_name)
	if attribute is None:
		raise Exception('Error: cannot find "{}" attribute'.format(at_name))
	return attribute

def _update_dummy_section(xobj):
	at_dummy_section = _get_xobj_attribute(xobj, 'dummy_section')
	Li = _get_xobj_attribute(xobj, 'Li').quantityScalar.value
	t = _get_xobj_attribute(xobj, 't').quantityScalar.value
	at_dummy_section.customObject = MpcBeamSection(
			MpcBeamSectionShapeType.Rectangular, 
			'section_Box', 'user', 'mm', [t, Li])

def onEditBegin(editor, xobj):
	'''
	This method is called as soon as the user begins to edit this object.
	So here we can do custom initialization
	'''
	# here we need to make sure the dummy section is created for the first time
	_update_dummy_section(xobj)

def onAttributeChanged(editor, xobj, attribute_name):
	'''
	This method is called everytime the value of an attribute is changed.
	The xobject containing the modified attribute and the attribute name
	are passed as input arguments to this function.
	'''
	if attribute_name == 'Li' or attribute_name == 't':
		# if Li or t changed, update the dummy section
		_update_dummy_section(xobj)

def makeExtrusionBeamDataCompoundInfo(xobj):
	
	# get the current document
	doc = App.caeDocument()
	if doc is None:
		raise Exception('no active cae document')
	
	# this element does not support transverse joint offset
	# as in other beam elements with geomTransf
	offset_y = 0.0
	offset_z = 0.0
	
	# make extrusion based on Type
	Type = _get_xobj_attribute(xobj, 'Type').string
	info = MpcSectionExtrusionBeamDataCompoundInfo()
	
	if Type == 'standard' or Type == 'tremuri':
		# Use the parent property of this XObject, because it is the container 
		# of the dummy_section
		if xobj.parent is not None:
			parent_id = xobj.parent.componentId
			prop = doc.getPhysicalProperty(parent_id)
			if prop is not None:
				# use the dummy section, 1, 2 or 3 based on the offsets
				offset_i = _get_xobj_attribute(xobj, 'Offset_i').quantityScalar.value
				offset_j = _get_xobj_attribute(xobj, 'Offset_j').quantityScalar.value
				if offset_i > 0.0:
					info.add(prop, offset_i, False, False, offset_y, offset_z) # is_param = False (real length)
				info.add(prop, 1.0, True, False, offset_y, offset_z) # is_param = True (parametric length)
				if offset_j > 0.0:
					info.add(prop, offset_j, False, False, offset_y, offset_z) # is_param = False (real length)
	
	elif Type == 'fiber':
		# use the provided fiber cross sections
		# for the offset i we will use the fiber i, likewise for offset j
		secI = doc.getPhysicalProperty(_get_xobj_attribute(xobj, 'SectionI').index)
		secE = doc.getPhysicalProperty(_get_xobj_attribute(xobj, 'SectionE').index)
		secJ = doc.getPhysicalProperty(_get_xobj_attribute(xobj, 'SectionJ').index)
		offset_i = _get_xobj_attribute(xobj, 'Offset_i').quantityScalar.value
		offset_j = _get_xobj_attribute(xobj, 'Offset_j').quantityScalar.value
		if offset_i > 0.0:
			info.add(secI, offset_i, False, False, offset_y, offset_z) # is_param = False (real length)
		info.add(secI, 0.495, True, False, offset_y, offset_z) # is_param = True (parametric length)
		info.add(secE, 0.01, True, False, offset_y, offset_z) # is_param = True (parametric length)
		info.add(secJ, 0.495, True, False, offset_y, offset_z) # is_param = True (parametric length)
		if offset_j > 0.0:
			info.add(secJ, offset_j, False, False, offset_y, offset_z) # is_param = False (real length)
		
	# done
	return info